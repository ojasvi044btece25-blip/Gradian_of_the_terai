"""Sentinel-1 GeoTIFF validation, loading, and alignment checking.

Assumptions
-----------
* Input files are **single-band** Sentinel-1 SAR backscatter GeoTIFFs.
* The radiometric scale (dB vs. linear power) is specified by the caller
  via ``ScaleHint``.  **This module never silently assumes a scale.**
* Nodata values must be declared in the GeoTIFF file header (GDAL nodata
  tag).  Pixels whose values happen to equal 0 are *not* automatically
  masked unless nodata is explicitly declared.
* Both scenes in a comparison pair must be pre-aligned: same CRS, same
  pixel dimensions, same affine transform.  Reprojection / resampling are
  outside the scope of this module.

Limitations
-----------
* No speckle filtering during loading.
* No radiometric terrain correction.
* No automatic detection of radiometric scale — the caller must specify.
"""
from __future__ import annotations

import enum
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np
import rasterio
from rasterio.crs import CRS
from rasterio.transform import Affine


# ---------------------------------------------------------------------------
# Public types
# ---------------------------------------------------------------------------

class ScaleHint(str, enum.Enum):
    """Indicates the radiometric scale of an input GeoTIFF.

    Attributes
    ----------
    DB:
        Values are already in decibel (dB) scale.  Flood detection
        operates directly on Δ = post_dB − pre_dB.
    LINEAR:
        Values are in linear **power** scale.  The module converts to dB
        using ``10 * log10(value)`` before detection.  If amplitude (not
        power) is provided, the caller must convert first.
        Non-positive pixels are masked as physically invalid.
    """

    DB = "db"
    LINEAR = "linear"


class ValidationError(ValueError):
    """Raised when a GeoTIFF fails format or metadata validation."""


class AlignmentError(ValueError):
    """Raised when two rasters are not spatially aligned."""


@dataclass(frozen=True)
class RasterMeta:
    """Key metadata extracted from a validated GeoTIFF."""

    path: Path
    crs: Optional[CRS]
    transform: Affine
    width: int
    height: int
    count: int
    dtype: str
    nodata: Optional[float]


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def validate_geotiff(path: "Path | str") -> RasterMeta:
    """Validate a file as an openable Sentinel-1 GeoTIFF.

    Parameters
    ----------
    path:
        Filesystem path to the GeoTIFF file.

    Returns
    -------
    RasterMeta
        Extracted metadata on success.

    Raises
    ------
    ValidationError
        If the file does not exist, cannot be opened by rasterio, has no
        bands, has no defined CRS, or carries an identity affine transform
        (which indicates missing geolocation metadata).
    """
    path = Path(path)

    if not path.exists():
        raise ValidationError(f"File not found: {path}")

    try:
        ds = rasterio.open(path)
    except Exception as exc:
        raise ValidationError(
            f"Cannot open '{path}' as a raster file: {exc}"
        ) from exc

    with ds:
        if ds.count < 1:
            raise ValidationError(f"'{path}' contains no bands.")

        if ds.crs is None:
            raise ValidationError(
                f"'{path}' has no CRS defined.  "
                "Ensure the file was projected/geocoded (e.g., via ESA SNAP) "
                "before use."
            )

        if ds.transform == rasterio.transform.IDENTITY:
            raise ValidationError(
                f"'{path}' has an identity (unit) affine transform, which "
                "indicates missing geolocation metadata.  "
                "Apply a geo-coding step before use."
            )

        return RasterMeta(
            path=path,
            crs=ds.crs,
            transform=ds.transform,
            width=ds.width,
            height=ds.height,
            count=ds.count,
            dtype=ds.dtypes[0],
            nodata=ds.nodata,
        )


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------

def load_band(
    path: "Path | str",
    band: int = 1,
    scale: ScaleHint = ScaleHint.DB,
) -> np.ma.MaskedArray:
    """Load one band from a GeoTIFF as a masked float32 array.

    Pixels that carry the file's declared nodata value are masked.
    If ``scale`` is ``ScaleHint.LINEAR``, the band is converted to dB
    after loading; non-positive pixels are additionally masked.

    Parameters
    ----------
    path:
        Path to the GeoTIFF.
    band:
        1-indexed band number to read (default: 1).
    scale:
        ``ScaleHint.DB`` (values already in dB) or
        ``ScaleHint.LINEAR`` (linear power, will be converted).
        **Never silently assumed** — the caller must pass the correct hint.

    Returns
    -------
    np.ma.MaskedArray
        Float32 masked array of shape ``(height, width)``.

    Raises
    ------
    ValidationError
        If the file cannot be opened or the requested band does not exist.
    """
    path = Path(path)

    try:
        with rasterio.open(path) as ds:
            if band > ds.count:
                raise ValidationError(
                    f"Band {band} requested but '{path}' has only "
                    f"{ds.count} band(s)."
                )
            # masked=True returns a MaskedArray; nodata positions are True in mask
            raw: np.ma.MaskedArray = ds.read(band, masked=True).astype(np.float32)
    except ValidationError:
        raise
    except Exception as exc:
        raise ValidationError(f"Failed to read band {band} from '{path}': {exc}") from exc

    if scale is ScaleHint.LINEAR:
        raw = _linear_to_db(raw)

    return raw


def _linear_to_db(arr: np.ma.MaskedArray) -> np.ma.MaskedArray:
    """Convert linear-power backscatter to dB (10 * log10).

    Non-positive values (physically meaningless in power scale) are
    masked as invalid in addition to any existing nodata mask.

    Parameters
    ----------
    arr:
        Float32 masked array in linear power scale.

    Returns
    -------
    np.ma.MaskedArray
        Float32 masked array in dB scale.
    """
    existing_mask: np.ndarray = np.ma.getmaskarray(arr)

    # Identify non-positive pixels (zero, negative, or NaN)
    data_filled = arr.filled(np.nan)  # fill masked positions to avoid log warnings
    non_positive_mask: np.ndarray = (data_filled <= 0) | ~np.isfinite(data_filled)

    combined_mask: np.ndarray = existing_mask | non_positive_mask

    # Safe log: replace invalid positions with 1.0 so log10(1.0)=0 (will be masked)
    safe_data = np.where(combined_mask, 1.0, data_filled)
    db_values = (10.0 * np.log10(safe_data)).astype(np.float32)

    return np.ma.array(db_values, mask=combined_mask)


# ---------------------------------------------------------------------------
# Alignment checking
# ---------------------------------------------------------------------------

#: Absolute tolerance for floating-point comparison of affine transform elements.
_TRANSFORM_TOL: float = 1e-9


def align_rasters(
    pre_path: "Path | str",
    post_path: "Path | str",
) -> "tuple[RasterMeta, RasterMeta]":
    """Assert that two rasters are spatially aligned.

    Validates both files individually, then checks that they share the
    same CRS, pixel dimensions, and affine transform (within floating-point
    tolerance).

    Parameters
    ----------
    pre_path, post_path:
        Paths to the two GeoTIFFs to compare.

    Returns
    -------
    tuple[RasterMeta, RasterMeta]
        Metadata for ``(pre, post)`` if all checks pass.

    Raises
    ------
    ValidationError
        If either file fails individual validation.
    AlignmentError
        If the two files differ in CRS, pixel shape, or affine transform.
        The error message enumerates all detected mismatches.
    """
    pre_meta = validate_geotiff(pre_path)
    post_meta = validate_geotiff(post_path)

    errors: list[str] = []

    # CRS check
    if pre_meta.crs != post_meta.crs:
        errors.append(
            f"CRS mismatch:\n"
            f"  pre : {pre_meta.crs}\n"
            f"  post: {post_meta.crs}"
        )

    # Pixel dimension check
    if (pre_meta.width, pre_meta.height) != (post_meta.width, post_meta.height):
        errors.append(
            f"Shape mismatch:\n"
            f"  pre : {pre_meta.width} × {pre_meta.height} px\n"
            f"  post: {post_meta.width} × {post_meta.height} px"
        )

    # Affine transform check
    if not _transforms_close(pre_meta.transform, post_meta.transform):
        errors.append(
            f"Transform mismatch:\n"
            f"  pre : {pre_meta.transform}\n"
            f"  post: {post_meta.transform}"
        )

    if errors:
        raise AlignmentError(
            "Pre-flood and post-flood rasters are not aligned.  "
            "Co-register both scenes (e.g., via ESA SNAP) before use.\n\n"
            + "\n\n".join(errors)
        )

    return pre_meta, post_meta


def _transforms_close(t1: Affine, t2: Affine, tol: float = _TRANSFORM_TOL) -> bool:
    """Return True if two Affine transforms are element-wise close."""
    return all(math.isclose(a, b, abs_tol=tol) for a, b in zip(t1, t2))
