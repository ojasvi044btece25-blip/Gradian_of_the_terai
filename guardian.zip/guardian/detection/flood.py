"""Flood detection by SAR backscatter change analysis.

Algorithm summary
-----------------
Flooding causes a significant reduction in Sentinel-1 SAR C-band
backscatter because open water acts as a near-specular reflector,
deflecting energy away from the sensor.  This module implements
threshold-based change detection:

    Δ = σ°_post (dB) − σ°_pre (dB)

A pixel is classified as *flooded* when Δ < ``threshold_db``
(default: −3 dB).

Scale requirement
-----------------
Detection operates in **dB space**.  Pass ``scale=ScaleHint.DB``
(default) when input files are already in dB, or ``scale=ScaleHint.LINEAR``
to trigger automatic conversion.  **The scale is never silently assumed.**

Nodata handling
---------------
A pixel is valid for analysis only when it is **not** masked in *both*
the pre-flood and post-flood scenes.  Pixels that are nodata in either
scene are excluded from all statistics and output.  This conservative
approach prevents fabricated flood classifications in data gaps.

Minimum area filter
-------------------
After thresholding, connected components with fewer than
``min_area_pixels`` pixels are removed.  This reduces isolated speckle
artefacts.  Full speckle filtering (e.g., Lee filter) is not applied.

Assumptions
-----------
* Both scenes are in the same radiometric scale (set via ``scale``).
* Both scenes are co-registered (checked via ``align_rasters``).
* The −3 dB threshold is a heuristic; it is configurable and should be
  validated against ground-truth data for the target region.

Limitations
-----------
* No terrain layover / shadow mask — steep slopes can cause false positives.
* No urban area mask — building double-bounce can mimic open water.
* Single-threshold approach; no ML classifier.
* Statistics are valid only within the extents of both uploaded scenes.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import rasterio
from scipy.ndimage import label as _ndimage_label

from guardian.config import DEFAULT_THRESHOLD_DB, MIN_AREA_PIXELS
from guardian.preprocessing.sentinel import (
    AlignmentError,   # re-exported so callers need only import from here
    ScaleHint,
    ValidationError,  # re-exported so callers need only import from here
    align_rasters,
    load_band,
)


# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------

@dataclass
class FloodResult:
    """Result of a single flood detection run.

    All statistics are derived from raster pixel arithmetic on the
    supplied input files.  **No values are fabricated.**

    Attributes
    ----------
    flood_mask:
        Boolean array ``(height, width)``.  ``True`` = flooded.
        Pixels where ``valid_mask`` is ``False`` are always ``False`` here.
    valid_mask:
        Boolean array ``(height, width)``.  ``True`` = pixel is non-nodata
        in *both* pre- and post-flood scenes.
    meta:
        Rasterio profile dict copied from the pre-flood scene.  Contains
        ``crs``, ``transform``, ``width``, ``height``, etc.  Used by
        output writers to preserve spatial metadata.
    flooded_pixel_count:
        Count of ``True`` cells in ``flood_mask``.
    valid_pixel_count:
        Count of ``True`` cells in ``valid_mask``.
    flooded_fraction:
        ``flooded_pixel_count / valid_pixel_count``.  Returns ``0.0`` when
        ``valid_pixel_count`` is 0 to avoid division by zero.
    threshold_db:
        The dB threshold used for this run (recorded for provenance).
    scale_used:
        The ``ScaleHint`` applied (recorded for provenance).
    """

    flood_mask: np.ndarray         # shape (H, W), dtype bool
    valid_mask: np.ndarray         # shape (H, W), dtype bool
    meta: dict                      # rasterio profile
    flooded_pixel_count: int
    valid_pixel_count: int
    flooded_fraction: float
    threshold_db: float
    scale_used: ScaleHint


# ---------------------------------------------------------------------------
# Main detection function
# ---------------------------------------------------------------------------

def detect_flood(
    pre_path: "Path | str",
    post_path: "Path | str",
    threshold_db: float = DEFAULT_THRESHOLD_DB,
    min_area_pixels: int = MIN_AREA_PIXELS,
    scale: ScaleHint = ScaleHint.DB,
) -> FloodResult:
    """Detect flooded pixels by comparing two Sentinel-1 SAR scenes.

    Parameters
    ----------
    pre_path:
        Path to the pre-flood Sentinel-1 GeoTIFF.
    post_path:
        Path to the post-flood Sentinel-1 GeoTIFF.
    threshold_db:
        Backscatter change threshold in dB.
        Pixels where ``σ°_post − σ°_pre < threshold_db`` are classified
        as flooded.  Default: −3 dB.
    min_area_pixels:
        Minimum pixel count for a connected flood component to be retained.
        Smaller components are removed as probable speckle noise.
        Set to 1 to disable filtering.
    scale:
        Radiometric scale of both input files.
        ``ScaleHint.DB`` (default) — values are already in dB.
        ``ScaleHint.LINEAR`` — values are linear power and will be
        converted to dB before comparison.
        **Never silently assumed.**

    Returns
    -------
    FloodResult

    Raises
    ------
    ValidationError
        If either file fails GeoTIFF validation.
    AlignmentError
        If the two files are not spatially aligned (CRS, shape, or
        transform mismatch).
    """
    pre_path = Path(pre_path)
    post_path = Path(post_path)

    # ── 1. Validate alignment first (fast fail) ──────────────────────────
    align_rasters(pre_path, post_path)  # raises ValidationError/AlignmentError

    # ── 2. Read rasterio profile for spatial metadata ────────────────────
    with rasterio.open(pre_path) as ds:
        meta: dict = ds.profile.copy()

    # ── 3. Load both bands as masked float32 arrays ──────────────────────
    pre_arr: np.ma.MaskedArray = load_band(pre_path, band=1, scale=scale)
    post_arr: np.ma.MaskedArray = load_band(post_path, band=1, scale=scale)

    # ── 4. Build valid mask: True where BOTH scenes have real data ────────
    pre_invalid: np.ndarray = np.ma.getmaskarray(pre_arr)
    post_invalid: np.ndarray = np.ma.getmaskarray(post_arr)
    valid_mask: np.ndarray = ~(pre_invalid | post_invalid)

    # ── 5. Compute backscatter change ─────────────────────────────────────
    # Fill masked positions with 0.0 — these are excluded by valid_mask
    delta: np.ndarray = post_arr.filled(0.0) - pre_arr.filled(0.0)

    # ── 6. Apply threshold, constrained to valid pixels ───────────────────
    raw_flood: np.ndarray = (delta < threshold_db) & valid_mask

    # ── 7. Minimum area filter (remove isolated speckle clusters) ─────────
    flood_mask: np.ndarray = _apply_min_area_filter(raw_flood, min_area_pixels)

    # ── 8. Compute summary statistics ────────────────────────────────────
    flooded_pixel_count: int = int(np.sum(flood_mask))
    valid_pixel_count: int = int(np.sum(valid_mask))
    flooded_fraction: float = (
        flooded_pixel_count / valid_pixel_count if valid_pixel_count > 0 else 0.0
    )

    return FloodResult(
        flood_mask=flood_mask,
        valid_mask=valid_mask,
        meta=meta,
        flooded_pixel_count=flooded_pixel_count,
        valid_pixel_count=valid_pixel_count,
        flooded_fraction=flooded_fraction,
        threshold_db=threshold_db,
        scale_used=scale,
    )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _apply_min_area_filter(
    flood_mask: np.ndarray,
    min_area_pixels: int,
) -> np.ndarray:
    """Remove flood connected components smaller than *min_area_pixels*.

    Parameters
    ----------
    flood_mask:
        Boolean array produced by the threshold step.
    min_area_pixels:
        Minimum retained component size (inclusive).
        Values <= 1 skip filtering entirely.

    Returns
    -------
    np.ndarray
        Filtered boolean array with the same shape as ``flood_mask``.
    """
    if min_area_pixels <= 1 or not np.any(flood_mask):
        return flood_mask.copy()

    labeled, n_features = _ndimage_label(flood_mask)
    if n_features == 0:
        return np.zeros_like(flood_mask, dtype=bool)

    # component_sizes[i] = pixel count for label i (index 0 = background)
    component_sizes: np.ndarray = np.bincount(labeled.ravel())

    # Build a lookup: True if the component is large enough to keep
    keep: np.ndarray = component_sizes >= min_area_pixels
    keep[0] = False  # background is never flood

    return keep[labeled].astype(bool)
