"""Vectorise a flood mask into a GeoJSON FeatureCollection.

Each contiguous flooded region is polygonised using
:func:`rasterio.features.shapes` and exported as a GeoJSON ``Feature``
with ``{"flooded": true}`` in its properties.

Coordinate reference system
----------------------------
If the source raster is not already in EPSG:4326 (WGS 84), each polygon
is reprojected using :func:`rasterio.warp.transform_geom` before writing.
This ensures the output is always in geographic coordinates (longitude /
latitude), compatible with web maps and GIS tools.

Notes
-----
* An empty ``FeatureCollection`` is written when no flooded pixels exist.
* Highly fragmented masks may produce many small polygons; polygon
  simplification is not applied in this version.
* Nodata / invalid pixels are never included in the output.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from rasterio.crs import CRS
from rasterio.features import shapes
from rasterio.warp import transform_geom

from guardian.detection.flood import FloodResult

_WGS84: CRS = CRS.from_epsg(4326)


def write_flood_geojson(flood_result: FloodResult, out_path: "Path | str") -> Path:
    """Polygonise the flood mask and write a GeoJSON FeatureCollection.

    Parameters
    ----------
    flood_result:
        Result from :func:`guardian.detection.flood.detect_flood`.
    out_path:
        Destination ``.geojson`` file path.  Parent directories are
        created if needed.

    Returns
    -------
    Path
        Resolved absolute path to the written file.
    """
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    src_crs: CRS | None = flood_result.meta.get("crs")
    transform = flood_result.meta["transform"]

    # uint8 rasterisation: 1=flooded, 0=everything else
    mask_u8: np.ndarray = flood_result.flood_mask.astype(np.uint8)

    features: list[dict] = []
    for geom_dict, pixel_value in shapes(mask_u8, transform=transform):
        if int(pixel_value) != 1:
            continue  # skip non-flooded background polygons

        # Reproject to WGS 84 if source CRS differs
        if src_crs is not None and src_crs != _WGS84:
            geom_dict = transform_geom(src_crs, _WGS84, geom_dict)

        features.append(
            {
                "type": "Feature",
                "geometry": geom_dict,
                "properties": {"flooded": True},
            }
        )

    feature_collection: dict = {
        "type": "FeatureCollection",
        "features": features,
    }

    with open(out_path, "w", encoding="utf-8") as fh:
        json.dump(feature_collection, fh, separators=(",", ":"))

    return out_path.resolve()
