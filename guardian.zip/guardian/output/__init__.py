"""GeoTIFF and GeoJSON output writers for flood detection results."""

from guardian.output.geotiff import write_flood_geotiff
from guardian.output.geojson import write_flood_geojson

__all__ = ["write_flood_geotiff", "write_flood_geojson"]
