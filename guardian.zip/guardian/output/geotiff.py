"""Write flood detection results as a classified GeoTIFF.

Output pixel encoding
---------------------
=====  ========================
Value  Meaning
=====  ========================
``0``  Valid pixel — not flooded
``1``  Valid pixel — flooded
``255`` Invalid / nodata (masked in either input scene)
=====  ========================

The output is a single-band uint8 GeoTIFF with DEFLATE compression,
using the same CRS and affine transform as the pre-flood input scene.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import rasterio

from guardian.config import NODATA_OUT
from guardian.detection.flood import FloodResult


def write_flood_geotiff(flood_result: FloodResult, out_path: "Path | str") -> Path:
    """Write the flood mask as a classified uint8 GeoTIFF.

    Parameters
    ----------
    flood_result:
        Result from :func:`guardian.detection.flood.detect_flood`.
    out_path:
        Destination file path.  Parent directories are created if needed.

    Returns
    -------
    Path
        Resolved absolute path to the written file.
    """
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    # Build output array: start with all-NODATA, then fill valid pixels
    out_arr = np.full(flood_result.flood_mask.shape, NODATA_OUT, dtype=np.uint8)
    out_arr[flood_result.valid_mask] = 0   # valid, not flooded
    out_arr[flood_result.flood_mask] = 1   # valid, flooded (always subset of valid)

    # Derive output profile from the pre-flood metadata, overriding data-type keys
    profile = flood_result.meta.copy()
    profile.update(
        dtype="uint8",
        count=1,
        nodata=NODATA_OUT,
        compress="deflate",
        predictor=2,   # horizontal differencing — safe and effective for uint8
    )
    # Remove tiling / interleaving settings that may conflict with a freshly
    # created file (they come from the source profile if it was tiled).
    for key in ("tiled", "interleave", "blockxsize", "blockysize"):
        profile.pop(key, None)

    with rasterio.open(out_path, "w", **profile) as ds:
        ds.write(out_arr, 1)

    return out_path.resolve()
