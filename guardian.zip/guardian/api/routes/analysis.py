"""Flood analysis endpoints.

POST /analyze
    Accept two Sentinel-1 GeoTIFFs (pre-flood, post-flood) as multipart
    file uploads.  Run flood detection and return statistics plus signed
    download URLs for the output GeoTIFF and GeoJSON.

GET /results/{job_id}/{filename}
    Download a previously generated output file.
    Only ``flood.tif`` and ``flood.geojson`` are served (allowlist).

Security notes
--------------
* The ``filename`` path parameter is validated against an allowlist to
  prevent path-traversal attacks.
* Uploaded files are saved to an isolated per-job directory under
  ``GUARDIAN_RESULTS_DIR``.  The job directory is removed on detection
  failure to avoid accumulating bad uploads.
"""
from __future__ import annotations

import shutil
import uuid
from pathlib import Path

from fastapi import APIRouter, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse

from guardian.config import get_results_dir
from guardian.detection.flood import detect_flood
from guardian.output.geojson import write_flood_geojson
from guardian.output.geotiff import write_flood_geotiff
from guardian.preprocessing.sentinel import AlignmentError, ValidationError

router = APIRouter()

# ── Security: allowlist for downloadable filenames ─────────────────────────
_ALLOWED_FILENAMES: frozenset[str] = frozenset({"flood.tif", "flood.geojson"})


# ---------------------------------------------------------------------------
# POST /analyze
# ---------------------------------------------------------------------------

@router.post("/analyze", summary="Run flood detection on two Sentinel-1 GeoTIFFs")
async def analyze(
    request: Request,
    pre_flood: UploadFile = File(
        ...,
        description=(
            "Pre-flood Sentinel-1 GeoTIFF.  Must be a single-band file in "
            "**dB scale**, co-registered with post_flood."
        ),
    ),
    post_flood: UploadFile = File(
        ...,
        description=(
            "Post-flood Sentinel-1 GeoTIFF.  Must be a single-band file in "
            "**dB scale**, co-registered with pre_flood."
        ),
    ),
) -> dict:
    """Detect flooded pixels by comparing two Sentinel-1 SAR scenes.

    Uploads are saved to a unique job directory.  Flood detection runs
    synchronously; outputs (GeoTIFF + GeoJSON) are written before this
    request returns.

    All statistics are derived from raster pixel arithmetic on the uploaded
    scenes.  **No values are fabricated.**

    Returns
    -------
    dict
        Job ID, flood statistics, and download URLs.
    """
    job_id: str = str(uuid.uuid4())
    job_dir: Path = get_results_dir() / job_id
    job_dir.mkdir(parents=True, exist_ok=True)

    pre_path: Path = job_dir / "pre_flood.tif"
    post_path: Path = job_dir / "post_flood.tif"

    # ── Save uploads ──────────────────────────────────────────────────────
    try:
        with open(pre_path, "wb") as fh:
            shutil.copyfileobj(pre_flood.file, fh)
        with open(post_path, "wb") as fh:
            shutil.copyfileobj(post_flood.file, fh)
    finally:
        await pre_flood.close()
        await post_flood.close()

    # ── Flood detection ───────────────────────────────────────────────────
    try:
        flood_result = detect_flood(pre_path, post_path)
    except (ValidationError, AlignmentError) as exc:
        shutil.rmtree(job_dir, ignore_errors=True)
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        shutil.rmtree(job_dir, ignore_errors=True)
        raise HTTPException(
            status_code=500,
            detail=f"Flood detection failed: {exc}",
        ) from exc

    # ── Write outputs ─────────────────────────────────────────────────────
    flood_tif: Path = job_dir / "flood.tif"
    flood_geojson: Path = job_dir / "flood.geojson"

    try:
        write_flood_geotiff(flood_result, flood_tif)
        write_flood_geojson(flood_result, flood_geojson)
    except Exception as exc:
        shutil.rmtree(job_dir, ignore_errors=True)
        raise HTTPException(
            status_code=500,
            detail=f"Failed to write output files: {exc}",
        ) from exc

    # ── Register job in app state ─────────────────────────────────────────
    request.app.state.jobs[job_id] = {
        "flood_tif": flood_tif,
        "flood_geojson": flood_geojson,
    }

    return {
        "job_id": job_id,
        "flooded_pixel_count": flood_result.flooded_pixel_count,
        "valid_pixel_count": flood_result.valid_pixel_count,
        "flooded_fraction": round(flood_result.flooded_fraction, 6),
        "flood_geotiff_url": f"/results/{job_id}/flood.tif",
        "flood_geojson_url": f"/results/{job_id}/flood.geojson",
        "note": (
            "Statistics are computed from raster pixel arithmetic on the "
            "uploaded scenes.  No values are fabricated or interpolated."
        ),
    }


# ---------------------------------------------------------------------------
# GET /results/{job_id}/{filename}
# ---------------------------------------------------------------------------

@router.get(
    "/results/{job_id}/{filename}",
    summary="Download a flood analysis result file",
)
async def get_result(
    job_id: str,
    filename: str,
    request: Request,
) -> FileResponse:
    """Download a generated flood analysis output.

    Parameters
    ----------
    job_id:
        UUID returned by ``POST /analyze``.
    filename:
        ``flood.tif``  — classified uint8 GeoTIFF (0=dry, 1=flood, 255=nodata).
        ``flood.geojson`` — vectorised flood polygons in WGS 84.

    Raises
    ------
    404
        If the job ID is unknown or the requested filename is not in the
        allowlist (path-traversal protection).
    """
    # Allowlist check (prevents path traversal via crafted filename)
    if filename not in _ALLOWED_FILENAMES:
        raise HTTPException(
            status_code=404,
            detail=(
                f"Unknown filename '{filename}'.  "
                f"Allowed: {sorted(_ALLOWED_FILENAMES)}"
            ),
        )

    jobs: dict = request.app.state.jobs
    if job_id not in jobs:
        raise HTTPException(
            status_code=404,
            detail=f"Job '{job_id}' not found.",
        )

    file_key: str = "flood_tif" if filename == "flood.tif" else "flood_geojson"
    file_path: Path = jobs[job_id][file_key]

    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Output file not found on disk.")

    media_type: str = (
        "image/tiff" if filename.endswith(".tif") else "application/geo+json"
    )
    return FileResponse(path=file_path, media_type=media_type, filename=filename)
