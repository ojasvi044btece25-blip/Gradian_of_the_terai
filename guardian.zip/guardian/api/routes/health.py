"""Health-check endpoint.

GET /health
    Returns service liveness status and current version.  This endpoint
    performs no I/O and is safe to poll at high frequency.
"""
from fastapi import APIRouter

from guardian.config import PROJECT_NAME, VERSION

router = APIRouter()


@router.get("/health", summary="Service health check")
def health_check() -> dict:
    """Return liveness status and build version.

    Returns
    -------
    dict
        ``{"status": "ok", "version": "<semver>", "service": "<name>"}``
    """
    return {
        "status": "ok",
        "version": VERSION,
        "service": PROJECT_NAME,
    }
