"""FastAPI application factory for Guardian of the Terai.

Usage
-----
Start the development server::

    uvicorn guardian.api.main:app --reload --host 0.0.0.0 --port 8000

The module-level ``app`` instance is suitable for uvicorn.
Use ``create_app()`` in tests to get an isolated instance with its own
``app.state``.
"""
from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from guardian.api.routes import analysis, health
from guardian.config import PROJECT_NAME, VERSION


@asynccontextmanager
async def _lifespan(app: FastAPI):
    """Initialise and clean up application-level state.

    ``app.state.jobs`` is a dict mapping ``job_id`` → file paths for
    generated outputs.  It lives only for the lifetime of the process;
    a database or object store should replace it for production use.
    """
    app.state.jobs: dict = {}
    yield
    # Future: close DB connections, clean up temp files, etc.


def create_app() -> FastAPI:
    """Create and configure a FastAPI application instance.

    Creating a new instance per test run keeps ``app.state`` isolated.
    """
    app = FastAPI(
        title=PROJECT_NAME,
        description=(
            "Satellite-based flood mapping system for Nepal's Terai region.  "
            "Compares pre-flood and post-flood Sentinel-1 SAR GeoTIFFs to "
            "detect flooded pixels via backscatter change thresholding."
        ),
        version=VERSION,
        lifespan=_lifespan,
        docs_url="/docs",
        redoc_url="/redoc",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(health.router, tags=["Health"])
    app.include_router(analysis.router, tags=["Analysis"])

    return app


# Module-level instance for uvicorn entry point
app: FastAPI = create_app()
