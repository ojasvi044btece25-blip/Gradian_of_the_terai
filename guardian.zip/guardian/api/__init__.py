"""FastAPI application for Guardian of the Terai."""
