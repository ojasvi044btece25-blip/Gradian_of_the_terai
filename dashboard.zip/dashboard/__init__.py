"""Streamlit dashboard helpers — presentation layer only."""
