"""Guardian of the Terai — Flood Intelligence Command Centre

Professional geospatial dashboard for flood detection and infrastructure exposure.
Reads existing analysis results and provides interactive visualization.
"""

import json
import os
from pathlib import Path
from typing import Any, Optional, Tuple

import geopandas as gpd
import pandas as pd
import streamlit as st
import folium
from streamlit_folium import st_folium
import rasterio
from rasterio.plot import show as rasterio_show
import numpy as np

# Page configuration
st.set_page_config(
    page_title="Guardian of the Terai",
    page_icon="🌊",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# Custom CSS - Professional dark theme
st.markdown(
    """
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    
    * { font-family: 'Inter', sans-serif; }
    
    .stApp {
        background-color: #0f1419;
    }
    
    .main .block-container {
        padding-top: 1rem;
        padding-bottom: 2rem;
    }
    
    /* Header */
    .header-container {
        background: linear-gradient(135deg, #1a2730 0%, #1a2730 100%);
        border: 1px solid #2d3e4a;
        border-radius: 8px;
        padding: 1.5rem 2rem;
        margin-bottom: 1.5rem;
    }
    .header-title {
        font-size: 1.8rem;
        font-weight: 700;
        color: #4fd1c5;
        margin: 0 0 0.5rem 0;
    }
    .header-subtitle {
        font-size: 0.95rem;
        color: #94a3b8;
        margin: 0 0 0.75rem 0;
    }
    .header-meta {
        font-size: 0.85rem;
        color: #64748b;
        display: flex;
        gap: 1.5rem;
        flex-wrap: wrap;
    }
    .header-meta span {
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
    }
    .status-badge {
        background: rgba(79, 209, 197, 0.15);
        color: #4fd1c5;
        padding: 0.25rem 0.75rem;
        border-radius: 4px;
        font-size: 0.75rem;
        font-weight: 600;
        border: 1px solid rgba(79, 209, 197, 0.3);
    }
    
    /* Section headers */
    .section-header {
        color: #e2e8f0;
        font-size: 1.25rem;
        font-weight: 600;
        margin: 1.5rem 0 1rem 0;
        border-bottom: 1px solid #2d3e4a;
        padding-bottom: 0.5rem;
    }
    
    /* Metric cards */
    .metric-card {
        background: #1a2730;
        border: 1px solid #2d3e4a;
        border-radius: 8px;
        padding: 1.25rem;
        height: 100%;
    }
    .metric-label {
        font-size: 0.75rem;
        color: #64748b;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 0.5rem;
    }
    .metric-value {
        font-size: 1.75rem;
        font-weight: 700;
        color: #e2e8f0;
        margin-bottom: 0.25rem;
    }
    .metric-sub {
        font-size: 0.8rem;
        color: #94a3b8;
    }
    
    /* Info boxes */
    .info-box {
        background: rgba(251, 146, 60, 0.08);
        border-left: 3px solid #fb923c;
        border-radius: 4px;
        padding: 0.75rem 1rem;
        margin: 1rem 0;
        font-size: 0.85rem;
        color: #fed7aa;
        line-height: 1.5;
    }
    
    .warning-box {
        background: rgba(239, 68, 68, 0.08);
        border-left: 3px solid #ef4444;
        border-radius: 4px;
        padding: 0.75rem 1rem;
        margin: 1rem 0;
        font-size: 0.85rem;
        color: #fca5a5;
        line-height: 1.5;
    }
    
    /* Hide default elements */
    #MainMenu {visibility: hidden;}
    .stDeployButton {display: none;}
    
    /* Streamlit elements */
    .stButton>button {
        background-color: #4fd1c5;
        color: #0f1419;
        border: none;
        border-radius: 4px;
        font-weight: 600;
    }
    .stButton>button:hover {
        background-color: #38b2ac;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# Paths
DATA_DIR = Path("data/vector")
FLOOD_DIR = DATA_DIR / "flood_extent"
IMPACT_DIR = DATA_DIR / "impact"
OSM_DIR = DATA_DIR / "osm"


def load_json_file(filepath: Path) -> Optional[dict]:
    """Load JSON file with error handling."""
    if not filepath.exists():
        return None
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        st.error(f"Error loading {filepath.name}: {e}")
        return None


def load_csv_file(filepath: Path) -> Optional[pd.DataFrame]:
    """Load CSV file with UTF-8 encoding."""
    if not filepath.exists():
        return None
    try:
        return pd.read_csv(filepath, encoding='utf-8')
    except Exception as e:
        st.error(f"Error loading {filepath.name}: {e}")
        return None


def load_geojson_file(filepath: Path) -> Optional[gpd.GeoDataFrame]:
    """Load GeoJSON file with error handling."""
    if not filepath.exists():
        return None
    try:
        return gpd.read_file(filepath)
    except Exception as e:
        st.error(f"Error loading {filepath.name}: {e}")
        return None


def load_flood_raster(filepath: Path) -> Optional[Tuple[np.ndarray, dict]]:
    """Load flood raster with metadata."""
    if not filepath.exists():
        return None
    try:
        with rasterio.open(filepath) as src:
            data = src.read(1)
            meta = {
                'crs': str(src.crs),
                'transform': src.transform,
                'bounds': src.bounds,
                'width': src.width,
                'height': src.height,
            }
            return data, meta
    except Exception as e:
        st.error(f"Error loading {filepath.name}: {e}")
        return None


def main():
    # Load reports
    flood_report = load_json_file(FLOOD_DIR / "flood_detection_report.json")
    impact_report = load_json_file(IMPACT_DIR / "impact_assessment_report.json")
    
    # Check data availability
    data_available = flood_report is not None or impact_report is not None
    
    if not data_available:
        st.error("❌ No analysis results found. Please run flood detection and settlement impact analysis first.")
        st.info("Expected files:")
        st.code("data/vector/flood_extent/flood_detection_report.json")
        st.code("data/vector/impact/impact_assessment_report.json")
        return
    
    # Header
    st.markdown(
        """
        <div class='header-container'>
            <div class='header-title'>🌊 Guardian of the Terai</div>
            <div class='header-subtitle'>Flood Intelligence Command Centre — Nepal Terai Region</div>
            <div class='header-meta'>
                <span>📍 <strong>Study Region:</strong> Saptari–Sunsari</span>
                <span>📅 <strong>Acquisition:</strong> 15 & 27 Sep 2024</span>
                <span><span class='status-badge'>✓ Candidate Data Available</span></span>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    
    # Extract metrics
    if flood_report:
        flood_area = flood_report["detection_statistics"]["candidate_flood_area_km2"]
        flooded_pixels = flood_report["detection_statistics"]["flooded_pixel_count"]
        valid_pixels = flood_report["detection_statistics"]["valid_pixel_count"]
        flood_pct = flood_report["detection_statistics"]["flooded_fraction"] * 100
        threshold = flood_report["processing_metadata"]["threshold_db"]
    else:
        flood_area = 0
        flooded_pixels = 0
        valid_pixels = 0
        flood_pct = 0
        threshold = -3.0
    
    if impact_report:
        settlements_flooded = impact_report["settlement_statistics"].get("settlements_with_flood_at_point", 0)
        total_settlements = impact_report["settlement_statistics"]["total_settlements"]
        roads_exposed = impact_report["road_statistics"].get("roads_with_exposure", 0)
        total_roads = impact_report["road_statistics"]["total_roads"]
        exposed_length_km = impact_report["road_statistics"].get("exposed_length_km", 0)
    else:
        settlements_flooded = 0
        total_settlements = 0
        roads_exposed = 0
        total_roads = 0
        exposed_length_km = 0
    
    # Metrics row
    st.markdown("### 📊 Detection Summary")
    m1, m2, m3, m4 = st.columns(4)
    
    with m1:
        st.markdown(
            f"""
            <div class='metric-card'>
                <div class='metric-label'>Candidate Flood Area</div>
                <div class='metric-value'>{flood_area:.1f} km²</div>
                <div class='metric-sub'>{flooded_pixels:,} pixels ({flood_pct:.1f}%)</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    
    with m2:
        st.markdown(
            f"""
            <div class='metric-card'>
                <div class='metric-label'>Settlements at Flood Point</div>
                <div class='metric-value'>{settlements_flooded}</div>
                <div class='metric-sub'>of {total_settlements:,} mapped points</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    
    with m3:
        st.markdown(
            f"""
            <div class='metric-card'>
                <div class='metric-label'>Roads Flagged</div>
                <div class='metric-value'>{roads_exposed}</div>
                <div class='metric-sub'>of {total_roads:,} mapped roads</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    
    with m4:
        st.markdown(
            f"""
            <div class='metric-card'>
                <div class='metric-label'>Exposed Road Length</div>
                <div class='metric-value'>{exposed_length_km:.1f} km</div>
                <div class='metric-sub'>approximate (midpoint)</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    
    # Workflow indicator
    st.markdown("### 🔄 Analysis Workflow")
    workflow_col1, workflow_col2, workflow_col3 = st.columns(3)
    
    with workflow_col1:
        st.markdown(
            f"""
            <div class='metric-card' style='border-left: 3px solid #4fd1c5;'>
                <div class='metric-label'>1. DETECT</div>
                <div class='metric-value' style='font-size: 1.25rem;'>Sentinel-1 Change Detection</div>
                <div class='metric-sub'>VV backscatter Δ < {threshold} dB</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    
    with workflow_col2:
        st.markdown(
            f"""
            <div class='metric-card' style='border-left: 3px solid #fb923c;'>
                <div class='metric-label'>2. ASSESS EXPOSURE</div>
                <div class='metric-value' style='font-size: 1.25rem;'>Infrastructure Overlap</div>
                <div class='metric-sub'>{settlements_flooded} settlements, {roads_exposed} roads</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    
    with workflow_col3:
        st.markdown(
            """
            <div class='metric-card' style='border-left: 3px solid #fca5a5;'>
                <div class='metric-label'>3. PRIORITIZE</div>
                <div class='metric-value' style='font-size: 1.25rem;'>Field Verification</div>
                <div class='metric-sub'>Ground truth required</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    
    # Interactive Map
    st.markdown("### 🗺️ Interactive Map")
    
    # Layer controls
    with st.expander("🎛️ Layer Controls", expanded=True):
        show_flood = st.checkbox("Candidate Flood Extent", value=False)
        show_settlements = st.checkbox("Settlements", value=False)
        show_settlements_flooded = st.checkbox("Show only flooded settlements", value=False)
        show_roads = st.checkbox("Roads", value=False)
        show_roads_exposed = st.checkbox("Show only exposed roads", value=False)
    
    # Create map with basemap only first
    try:
        # Center on study area (Saptari-Sunsari)
        center_lat = 26.64
        center_lon = 86.92
        
        m = folium.Map(
            location=[center_lat, center_lon],
            zoom_start=10,
            tiles="OpenStreetMap",
            control_scale=True,
        )
        
        # Add flood extent (simplified subset for performance)
        if show_flood:
            flood_gdf = load_geojson_file(FLOOD_DIR / "flood_extent.geojson")
            if flood_gdf is not None and len(flood_gdf) > 0:
                try:
                    # Use very sparse subset for display (every 500th polygon)
                    flood_subset = flood_gdf.iloc[::500].copy()
                    # Drop all properties except geometry to avoid serialization issues
                    flood_subset = flood_subset[['geometry']]
                    folium.GeoJson(
                        flood_subset.__geo_interface__,
                        name="Candidate Flood Extent (display subset)",
                        style_function=lambda x: {
                            "fillColor": "#ef4444",
                            "color": "#dc2626",
                            "weight": 1,
                            "fillOpacity": 0.4,
                        },
                        tooltip="Candidate flood extent (display subset for performance)"
                    ).add_to(m)
                except Exception as e:
                    st.warning(f"Could not load flood layer: {e}")
        
        # Add settlements
        if show_settlements:
            settlement_gdf = load_geojson_file(IMPACT_DIR / "settlement_impact.geojson")
            if settlement_gdf is not None:
                try:
                    if show_settlements_flooded and 'candidate_flood_at_point' in settlement_gdf.columns:
                        display_gdf = settlement_gdf[settlement_gdf['candidate_flood_at_point'] == True].copy()
                        color = "#fb923c"  # Amber for flooded
                    else:
                        display_gdf = settlement_gdf.copy()
                        color = "#4fd1c5"  # Teal for all
                    
                    if len(display_gdf) > 0:
                        # Sample for performance if too many
                        if len(display_gdf) > 200:
                            display_gdf = display_gdf.sample(n=200, random_state=42)
                        
                        # Keep only essential columns
                        essential_cols = ['geometry', 'name', 'osmid']
                        for col in essential_cols:
                            if col not in display_gdf.columns:
                                essential_cols.remove(col)
                        display_gdf = display_gdf[essential_cols]
                        
                        for idx, row in display_gdf.iterrows():
                            if row.geometry.geom_type == 'Point':
                                folium.CircleMarker(
                                    location=[row.geometry.y, row.geometry.x],
                                    radius=4,
                                    color=color,
                                    fill=True,
                                    fillColor=color,
                                    fillOpacity=0.8,
                                    popup=f"<b>Settlement:</b> {row.get('name', 'Unknown')}<br><b>OSM ID:</b> {row.get('osmid', 'N/A')}",
                                    tooltip=row.get('name', 'Unknown')
                                ).add_to(m)
                except Exception as e:
                    st.warning(f"Could not load settlement layer: {e}")
        
        # Add roads
        if show_roads:
            road_gdf = load_geojson_file(IMPACT_DIR / "road_impact.geojson")
            if road_gdf is not None:
                try:
                    if show_roads_exposed and 'candidate_flood_exposure' in road_gdf.columns:
                        display_gdf = road_gdf[road_gdf['candidate_flood_exposure'] == True].copy()
                        color = "#fb923c"  # Amber for exposed
                    else:
                        display_gdf = road_gdf.copy()
                        color = "#64748b"  # Gray for all
                    
                    if len(display_gdf) > 0:
                        # Sample for performance
                        if len(display_gdf) > 100:
                            display_gdf = display_gdf.sample(n=100, random_state=42)
                        
                        # Keep only essential columns
                        essential_cols = ['geometry', 'name', 'osmid']
                        for col in essential_cols:
                            if col not in display_gdf.columns:
                                essential_cols.remove(col)
                        display_gdf = display_gdf[essential_cols]
                        
                        folium.GeoJson(
                            display_gdf.__geo_interface__,
                            name="Roads (display subset)",
                            style_function=lambda x: {
                                "color": color,
                                "weight": 2,
                                "opacity": 0.7,
                            },
                            tooltip=lambda x: f"Road: {x['properties'].get('name', 'Unknown')}"
                        ).add_to(m)
                except Exception as e:
                    st.warning(f"Could not load road layer: {e}")
        
        # Add layer control
        folium.LayerControl().add_to(m)
        
        # Fit bounds to study area
        m.fit_bounds([[26.40, 86.48], [26.88, 87.35]])
        
        # Display map
        st_folium(m, use_container_width=True, height=600)
        
    except Exception as e:
        st.error(f"Map error: {e}")
        import traceback
        st.error(traceback.format_exc())
    
    # Analysis Details
    st.markdown("### 📋 Analysis Details")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Settlement Exposure")
        if impact_report:
            st.metric("Total Settlements", f"{total_settlements:,}")
            st.metric("At Flood Point", f"{settlements_flooded} ({settlements_flooded/total_settlements*100:.1f}%)")
            st.markdown(
                """
                <div class='info-box'>
                ℹ️ <strong>Method:</strong> Binary point sampling<br>
                Settlements are point features. The metric indicates whether the settlement point 
                intersects a flooded pixel, not flooded area. Cannot estimate % of settlement flooded.
                </div>
                """,
                unsafe_allow_html=True,
            )
        else:
            st.warning("Settlement impact data not available")
    
    with col2:
        st.subheader("Road Exposure")
        if impact_report:
            st.metric("Total Roads", f"{total_roads:,}")
            st.metric("Flagged for Exposure", f"{roads_exposed} ({roads_exposed/total_roads*100:.1f}%)")
            st.metric("Exposed Length", f"{exposed_length_km:.1f} km")
            st.markdown(
                """
                <div class='info-box'>
                ⚠️ <strong>Method:</strong> Midpoint sampling approximation<br>
                If road midpoint is flooded, estimates 50% length exposure. 
                Not exact length calculation.
                </div>
                """,
                unsafe_allow_html=True,
            )
        else:
            st.warning("Road impact data not available")
    
    # Building analysis status
    st.markdown("### 🏗️ Building Analysis")
    st.markdown(
        """
        <div class='warning-box'>
        ⚠️ <strong>Building-level analysis not performed</strong><br>
        601,837 buildings too computationally intensive for current timeframe. 
        Building exposure would require rasterizing each footprint and sampling multiple points per building.
        </div>
        """,
        unsafe_allow_html=True,
    )
    
    # Scientific Disclaimer
    st.markdown("### ⚠️ Scientific Disclaimer")
    st.markdown(
        """
        <div class='info-box' style='background: rgba(239, 68, 68, 0.08); border-left-color: #ef4444; color: #fca5a5;'>
        <strong>Candidate Data Only:</strong> This output is derived from Sentinel-1 backscatter change detection 
        and has NOT been validated against independent reference data. The 12-day temporal gap between 
        acquisitions (Sep 15–27) means changes may include non-flood phenomena. Threshold-based detection 
        cannot reliably distinguish floodwater from all other low-backscatter surfaces.
        
        <br><br>
        <strong>Infrastructure Exposure:</strong> Settlement and road results indicate potential exposure 
        to candidate flood extent, not confirmed damage. Road exposure uses midpoint sampling approximation. 
        Independent validation with ground truth or optical imagery is required before operational use.
        </div>
        """,
        unsafe_allow_html=True,
    )
    
    # Downloads
    st.markdown("### ⬇️ Export Results")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Flood Detection")
        
        flood_tif = FLOOD_DIR / "flood_extent.tif"
        if flood_tif.exists():
            with open(flood_tif, "rb") as f:
                st.download_button(
                    "📥 Flood GeoTIFF (binary mask)",
                    data=f.read(),
                    file_name="flood_extent.tif",
                    mime="image/tiff",
                    use_container_width=True,
                )
        
        flood_geojson = FLOOD_DIR / "flood_extent.geojson"
        if flood_geojson.exists():
            with open(flood_geojson, "r", encoding='utf-8') as f:
                st.download_button(
                    "📥 Flood GeoJSON (polygons)",
                    data=f.read(),
                    file_name="flood_extent.geojson",
                    mime="application/geo+json",
                    use_container_width=True,
                )
        
        if flood_report:
            st.download_button(
                "📥 Detection Report (JSON)",
                data=json.dumps(flood_report, indent=2),
                file_name="flood_detection_report.json",
                mime="application/json",
                use_container_width=True,
            )
    
    with col2:
        st.subheader("Impact Assessment")
        
        impact_files = [
            ("Settlement CSV", IMPACT_DIR / "settlement_impact.csv", "text/csv"),
            ("Settlement GeoJSON", IMPACT_DIR / "settlement_impact.geojson", "application/geo+json"),
            ("Road CSV", IMPACT_DIR / "road_impact.csv", "text/csv"),
            ("Road GeoJSON", IMPACT_DIR / "road_impact.geojson", "application/geo+json"),
        ]
        
        for label, filepath, mime in impact_files:
            if filepath.exists():
                try:
                    with open(filepath, "r", encoding='utf-8') as f:
                        st.download_button(
                            f"📥 {label}",
                            data=f.read(),
                            file_name=filepath.name,
                            mime=mime,
                            use_container_width=True,
                        )
                except Exception as e:
                    st.warning(f"Could not prepare {label}: {e}")
        
        if impact_report:
            st.download_button(
                "📥 Impact Report (JSON)",
                data=json.dumps(impact_report, indent=2),
                file_name="impact_assessment_report.json",
                mime="application/json",
                use_container_width=True,
            )
    
    # Processing Status
    st.markdown("### ⚙️ Processing Status")
    
    status_col1, status_col2 = st.columns(2)
    
    with status_col1:
        st.subheader("Flood Detection")
        if flood_report:
            st.success("✅ Complete")
            st.caption(f"Threshold: {threshold} dB")
            st.caption(f"Pixels: {flooded_pixels:,} / {valid_pixels:,} flooded")
            st.caption(f"Acquisition: Sep 15 & 27, 2024")
        else:
            st.warning("⚠️ Not found")
    
    with status_col2:
        st.subheader("Settlement Impact")
        if impact_report:
            st.success("✅ Complete")
            method = impact_report["processing_metadata"].get("method", "Unknown")
            duration = impact_report["processing_metadata"].get("duration_seconds", 0)
            st.caption(f"Method: {method}")
            st.caption(f"Duration: {duration:.1f}s")
        else:
            st.warning("⚠️ Not found")


if __name__ == "__main__":
    main()
