"""Guardian of the Terai — Streamlit Dashboard (Polished Version)

Loads and visualizes existing flood detection and settlement impact results.
Dark theme with teal/cyan/amber accents for a premium command center look.
"""

import json
import os
from pathlib import Path
from typing import Any, Optional

import geopandas as gpd
import pandas as pd
import streamlit as st
import plotly.graph_objects as go
import plotly.express as px

# Page configuration
st.set_page_config(
    page_title="Guardian of the Terai",
    page_icon="🌊",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# Custom CSS - Dark theme with premium styling
st.markdown(
    """
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    
    * { font-family: 'Inter', sans-serif; }
    
    .stApp {
        background-color: #0a0e14;
    }
    
    /* Main container */
    .main .block-container {
        padding-top: 2rem;
    }
    
    /* Header */
    .dashboard-header {
        background: linear-gradient(135deg, #1e3a5f 0%, #1e3a5f 50%, #2d4a3e 100%);
        border-radius: 12px;
        padding: 2rem 2.5rem;
        color: #e0e0e0;
        margin-bottom: 2rem;
        border: 1px solid #334155;
    }
    .dashboard-header h1 { 
        font-size: 2.5rem; 
        margin: 0 0 0.5rem 0; 
        font-weight: 700; 
        color: #4fd1c5;
    }
    .dashboard-header .subtitle { 
        font-size: 1.1rem; 
        margin: 0 0 1rem 0; 
        color: #b0bec5; 
        font-weight: 400;
    }
    .dashboard-header .meta {
        font-size: 0.9rem;
        color: #81c784;
        margin-top: 0.5rem;
    }
    
    /* KPI Cards */
    .kpi-card {
        background: linear-gradient(135deg, #1e3a5f 0%, #16213e 100%);
        border: 1px solid #334155;
        border-radius: 12px;
        padding: 1.5rem;
        color: #e0e0e0;
        height: 100%;
    }
    .kpi-label {
        font-size: 0.75rem;
        color: #81c784;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 0.5rem;
    }
    .kpi-value {
        font-size: 2.2rem;
        font-weight: 700;
        color: #4fd1c5;
        margin-bottom: 0.25rem;
    }
    .kpi-sub {
        font-size: 0.85rem;
        color: #b0bec5;
    }
    
    /* Section headers */
    .section-header {
        color: #e0e0e0;
        font-size: 1.5rem;
        font-weight: 600;
        margin: 2rem 0 1rem 0;
        border-bottom: 1px solid #334155;
        padding-bottom: 0.5rem;
    }
    
    /* Disclaimer */
    .disclaimer {
        background: rgba(251, 146, 60, 0.1);
        border-left: 4px solid #ff9800;
        border-radius: 8px;
        padding: 1rem 1.5rem;
        margin: 2rem 0;
        font-size: 0.85rem;
        color: #ffb74d;
        line-height: 1.6;
    }
    
    /* Status badges */
    .status-badge {
        display: inline-block;
        padding: 0.3rem 0.8rem;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 600;
    }
    .status-success {
        background: rgba(76, 175, 80, 0.2);
        color: #4fd1c5;
        border: 1px solid #4fd1c5;
    }
    .status-warning {
        background: rgba(255, 152, 0, 0.1);
        color: #ffb74d;
        border: 1px solid #ffb74d;
    }
    
    /* File download buttons */
    .download-btn {
        margin-bottom: 0.5rem;
    }
    
    /* Hide streamlit default elements */
    #MainMenu {visibility: hidden;}
    .stDeployButton {display: none;}
    </style>
    """,
    unsafe_allow_html=True,
)

# Paths
DATA_DIR = Path("data/vector")
FLOOD_DIR = DATA_DIR / "flood_extent"
IMPACT_DIR = DATA_DIR / "impact"
OSM_DIR = DATA_DIR / "osm"


def load_flood_report() -> Optional[dict]:
    """Load flood detection report."""
    report_path = FLOOD_DIR / "flood_detection_report.json"
    if report_path.exists():
        with open(report_path) as f:
            return json.load(f)
    return None


def load_impact_report() -> Optional[dict]:
    """Load settlement impact report."""
    report_path = IMPACT_DIR / "impact_assessment_report.json"
    if report_path.exists():
        with open(report_path) as f:
            return json.load(f)
    return None


def check_file_exists(filepath: Path) -> bool:
    """Check if a file exists and can be read."""
    return filepath.exists() and filepath.stat().st_size > 0


def main():
    # Header
    st.markdown(
        """
        <div class='dashboard-header'>
            <h1>🌊 Guardian of the Terai</h1>
            <p class='subtitle'>Flood intelligence and potential infrastructure exposure</p>
            <div class='meta'>
                <strong>Study Region:</strong> Saptari–Sunsari, Nepal &nbsp;|&nbsp;
                <strong>Analysis Dates:</strong> 15 and 27 September 2024 &nbsp;|&nbsp;
                <span class='status-badge status-success'>✓ Candidate Data Available</span>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    
    # Load reports
    flood_report = load_flood_report()
    impact_report = load_impact_report()
    
    # Check availability
    data_available = flood_report is not None or impact_report is not None
    
    if not data_available:
        st.error("❌ No analysis results found. Please run flood detection and settlement impact analysis first.")
        st.info("Expected files:")
        st.code("data/vector/flood_extent/flood_detection_report.json")
        st.code("data/vector/impact/impact_assessment_report.json")
        return
    
    # KPI Cards
    st.markdown("### 📊 Key Performance Indicators")
    
    if flood_report:
        flood_area = flood_report["detection_statistics"]["candidate_flood_area_km2"]
        flooded_pixels = flood_report["detection_statistics"]["flooded_pixel_count"]
        valid_pixels = flood_report["detection_statistics"]["valid_pixel_count"]
        flood_pct = flood_report["detection_statistics"]["flooded_fraction"] * 100
    else:
        flood_area = 0
        flooded_pixels = 0
        valid_pixels = 0
        flood_pct = 0
    
    if impact_report:
        settlements_flooded = impact_report["settlement_statistics"].get("settlements_with_flood_at_point", 0)
        total_settlements = impact_report["settlement_statistics"]["total_settlements"]
        roads_exposed = impact_report["road_statistics"].get("roads_with_exposure", 0)
        total_roads = impact_report["road_statistics"]["total_roads"]
        exposed_length_km = impact_report["road_statistics"].get("exposed_length_km", 0)
    else:
        settlements_flooded = 0
        total_settlements = 0
        roads_exposed = 0
        total_roads = 0
        exposed_length_km = 0
    
    kpi1, kpi2, kpi3, kpi4 = st.columns(4)
    
    with kpi1:
        st.markdown(
            f"""
            <div class='kpi-card'>
                <div class='kpi-label'>Candidate Flood Area</div>
                <div class='kpi-value'>{flood_area:.1f} km²</div>
                <div class='kpi-sub'>{flooded_pixels:,} pixels ({flood_pct:.1f}%)</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    
    with kpi2:
        st.markdown(
            f"""
            <div class='kpi-card'>
                <div class='kpi-label'>Settlements at Flood Point</div>
                <div class='kpi-value'>{settlements_flooded}</div>
                <div class='kpi-sub'>of {total_settlements:,} mapped points</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    
    with kpi3:
        st.markdown(
            f"""
            <div class='kpi-card'>
                <div class='kpi-label'>Roads Flagged</div>
                <div class='kpi-value'>{roads_exposed}</div>
                <div class='kpi-sub'>of {total_roads:,} mapped roads</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    
    with kpi4:
        st.markdown(
            f"""
            <div class='kpi-card'>
                <div class='kpi-label'>Exposed Road Length</div>
                <div class='kpi-value'>{exposed_length_km:.1f} km</div>
                <div class='kpi-sub'>approximate (midpoint sampling)</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    
    # Disclaimer
    st.markdown(
        """
        <div class='disclaimer'>
            <strong>⚠️ Scientific Disclaimer:</strong> Candidate flood extent derived from Sentinel-1 backscatter change detection. Not independently validated. Settlement and road results indicate potential exposure, not confirmed damage. 12-day temporal gap between acquisitions. Road exposure uses midpoint approximation (not exact length).
        </div>
        """,
        unsafe_allow_html=True,
    )
    
    # Interactive Map
    st.markdown("### 🗺️ Interactive Map")
    
    try:
        from streamlit_folium import st_folium
        import folium
        
        # Create base map centered on study area
        m = folium.Map(
            location=[26.64, 86.92],
            zoom_start=10,
            tiles=None,
        )
        # Add dark basemap
        folium.TileLayer(
            tiles='https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
            attr='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
            name='Dark Matter',
            control=True,
            overlay=False
        ).add_to(m)
        
        # Add flood extent if available
        flood_geojson_path = FLOOD_DIR / "flood_extent.geojson"
        if check_file_exists(flood_geojson_path):
            try:
                gdf_flood = gpd.read_file(flood_geojson_path)
                # Simplify: only show every 10th polygon for performance
                gdf_flood_simple = gdf_flood.iloc[::10]
                folium.GeoJson(
                    gdf_flood_simple.__geo_interface__,
                    name="Candidate Flood Extent",
                    style_function=lambda x: {
                        "fillColor": "#ff6b6b",
                        "color": "#c92a2a",
                        "weight": 1,
                        "fillOpacity": 0.5,
                    },
                    tooltip="Flood extent (simplified display)"
                ).add_to(m)
            except Exception as e:
                st.warning(f"Could not load flood extent: {e}")
        
        # Add settlements if available
        settlements_path = OSM_DIR / "settlements.geojson"
        settlement_impact_path = IMPACT_DIR / "settlement_impact.geojson"
        
        if check_file_exists(settlement_impact_path):
            try:
                gdf_settlements = gpd.read_file(settlement_impact_path)
                # Filter to only show flooded settlements
                gdf_flooded = gdf_settlements[gdf_settlements["candidate_flood_at_point"] == True]
                
                if len(gdf_flooded) > 0:
                    folium.GeoJson(
                        gdf_flooded.__geo_interface__,
                        name="Settlements at Flood Point",
                        style_function=lambda x: {
                            "radius": 4,
                            "fillColor": "#4fd1c5",
                            "color": "#00bcd4",
                            "weight": 2,
                            "fillOpacity": 0.8,
                        },
                        tooltip=f"Flooded settlements: {len(gdf_flooded)}"
                    ).add_to(m)
            except Exception as e:
                st.warning(f"Could not load settlements: {e}")
        
        # Add exposed roads if available
        road_impact_path = IMPACT_DIR / "road_impact.geojson"
        if check_file_exists(road_impact_path):
            try:
                gdf_roads = gpd.read_file(road_impact_path)
                # Filter to only show exposed roads
                gdf_exposed = gdf_roads[gdf_roads["candidate_flood_exposure"] == True]
                
                if len(gdf_exposed) > 0:
                    # Simplify: show every 50th road for performance
                    gdf_exposed_simple = gdf_exposed.iloc[::50]
                    folium.GeoJson(
                        gdf_exposed_simple.__geo_interface__,
                        name="Roads with Exposure",
                        style_function=lambda x: {
                            "color": "#ffb74d",
                            "weight": 2,
                            "opacity": 0.7,
                        },
                        tooltip=f"Exposed roads (simplified): {len(gdf_exposed_simple)}"
                    ).add_to(m)
            except Exception as e:
                st.warning(f"Could not load roads: {e}")
        
        folium.LayerControl().add_to(m)
        st_folium(m, use_container_width=True, height=600)
        
    except ImportError:
        st.warning("Install streamlit-folium for interactive map: `pip install streamlit-folium`")
    except Exception as e:
        st.error(f"Map error: {e}")
    
    # Analysis Panel
    st.markdown("### 📈 Analysis & Exposure")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Settlement Exposure")
        if impact_report:
            st.metric("Total Settlements", f"{total_settlements:,}")
            st.metric("At Flood Point", f"{settlements_flooded} ({settlements_flooded/total_settlements*100:.1f}%)")
            
            st.info("ℹ️ Settlements are point features - metric indicates whether the settlement point intersects a flooded pixel, not flooded area.")
        else:
            st.warning("Settlement impact data not available")
    
    with col2:
        st.subheader("Road Exposure")
        if impact_report:
            st.metric("Total Roads", f"{total_roads:,}")
            st.metric("Flagged for Exposure", f"{roads_exposed} ({roads_exposed/total_roads*100:.1f}%)")
            st.metric("Exposed Length", f"{exposed_length_km:.1f} km")
            
            st.info("⚠️ Road exposure uses midpoint sampling approximation - not exact length calculation.")
        else:
            st.warning("Road impact data not available")
    
    # Buildings Status
    st.markdown("### 🏗️ Building Analysis")
    st.info("ℹ️ Building-level analysis not performed - 601,837 buildings too computationally intensive for current timeframe.")
    
    # Downloads
    st.markdown("### ⬇️ Download Results")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Flood Detection")
        
        if check_file_exists(FLOOD_DIR / "flood_extent.tif"):
            with open(FLOOD_DIR / "flood_extent.tif", "rb") as f:
                st.download_button(
                    "📥 Flood GeoTIFF",
                    data=f.read(),
                    file_name="flood_extent.tif",
                    mime="image/tiff",
                    use_container_width=True,
                )
        
        if check_file_exists(FLOOD_DIR / "flood_extent.geojson"):
            with open(FLOOD_DIR / "flood_extent.geojson", "r") as f:
                st.download_button(
                    "📥 Flood GeoJSON",
                    data=f.read(),
                    file_name="flood_extent.geojson",
                    mime="application/geo+json",
                    use_container_width=True,
                )
        
        if check_file_exists(FLOOD_DIR / "flood_detection_report.json"):
            with open(FLOOD_DIR / "flood_detection_report.json", "r") as f:
                st.download_button(
                    "📥 Detection Report",
                    data=f.read(),
                    file_name="flood_detection_report.json",
                    mime="application/json",
                    use_container_width=True,
                )
    
    with col2:
        st.subheader("Settlement Impact")
        
        if check_file_exists(IMPACT_DIR / "settlement_impact.csv"):
            with open(IMPACT_DIR / "settlement_impact.csv", "r") as f:
                st.download_button(
                    "📥 Settlement CSV",
                    data=f.read(),
                    file_name="settlement_impact.csv",
                    mime="text/csv",
                    use_container_width=True,
                )
        
        if check_file_exists(IMPACT_DIR / "settlement_impact.geojson"):
            with open(IMPACT_DIR / "settlement_impact.geojson", "r") as f:
                st.download_button(
                    "📥 Settlement GeoJSON",
                    data=f.read(),
                    file_name="settlement_impact.geojson",
                    mime="application/geo+json",
                    use_container_width=True,
                )
        
        if check_file_exists(IMPACT_DIR / "road_impact.csv"):
            with open(IMPACT_DIR / "road_impact.csv", "r") as f:
                st.download_button(
                    "📥 Road CSV",
                    data=f.read(),
                    file_name="road_impact.csv",
                    mime="text/csv",
                    use_container_width=True,
                )
        
        if check_file_exists(IMPACT_DIR / "road_impact.geojson"):
            with open(IMPACT_DIR / "road_impact.geojson", "r") as f:
                st.download_button(
                    "📥 Road GeoJSON",
                    data=f.read(),
                    file_name="road_impact.geojson",
                    mime="application/geo+json",
                    use_container_width=True,
                )
        
        if check_file_exists(IMPACT_DIR / "impact_assessment_report.json"):
            with open(IMPACT_DIR / "impact_assessment_report.json", "r") as f:
                st.download_button(
                    "📥 Impact Report",
                    data=f.read(),
                    file_name="impact_assessment_report.json",
                    mime="application/json",
                    use_container_width=True,
                )
    
    # Processing Status
    st.markdown("### ⚙️ Processing Status")
    
    status_col1, status_col2 = st.columns(2)
    
    with status_col1:
        st.subheader("Flood Detection")
        if flood_report:
            st.success("✅ Complete")
            st.caption(f"Threshold: {flood_report['processing_metadata']['threshold_db']} dB")
            st.caption(f"Pixels: {flooded_pixels:,} / {valid_pixels:,} flooded")
        else:
            st.warning("⚠️ Not found")
    
    with status_col2:
        st.subheader("Settlement Impact")
        if impact_report:
            st.success("✅ Complete")
            st.caption(f"Method: {impact_report['processing_metadata']['method']}")
            st.caption(f"Duration: {impact_report['processing_metadata']['duration_seconds']:.1f}s")
        else:
            st.warning("⚠️ Not found")


if __name__ == "__main__":
    main()
